﻿
namespace Student_Addmission_Form
{
    partial class Frm_Add_New_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Lbl_Roll_No = new System.Windows.Forms.Label();
            this.Lbl_Name = new System.Windows.Forms.Label();
            this.Lbl_Mobile_No = new System.Windows.Forms.Label();
            this.Lbl_DOB = new System.Windows.Forms.Label();
            this.Lbl_Pass = new System.Windows.Forms.Label();
            this.Btn_Save = new System.Windows.Forms.Button();
            this.Tb_Name = new System.Windows.Forms.TextBox();
            this.Tb_Roll_No = new System.Windows.Forms.TextBox();
            this.Tb_No = new System.Windows.Forms.TextBox();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.Cmb_Course = new System.Windows.Forms.ComboBox();
            this.Btn_student_List = new System.Windows.Forms.Button();
            this.Btn_Refresh = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.Button();
            this.Btn_User = new System.Windows.Forms.Button();
            this.Btn_Update_Student = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PapayaWhip;
            this.label1.Font = new System.Drawing.Font("Rockwell", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(265, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(812, 96);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Student Details";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Lbl_Roll_No
            // 
            this.Lbl_Roll_No.AutoSize = true;
            this.Lbl_Roll_No.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Roll_No.Location = new System.Drawing.Point(119, 274);
            this.Lbl_Roll_No.Name = "Lbl_Roll_No";
            this.Lbl_Roll_No.Size = new System.Drawing.Size(127, 34);
            this.Lbl_Roll_No.TabIndex = 0;
            this.Lbl_Roll_No.Text = "Roll No";
            this.Lbl_Roll_No.Click += new System.EventHandler(this.Lbl_Roll_No_Click);
            // 
            // Lbl_Name
            // 
            this.Lbl_Name.AutoSize = true;
            this.Lbl_Name.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Name.Location = new System.Drawing.Point(119, 162);
            this.Lbl_Name.Name = "Lbl_Name";
            this.Lbl_Name.Size = new System.Drawing.Size(213, 34);
            this.Lbl_Name.TabIndex = 0;
            this.Lbl_Name.Text = "Student Name";
            // 
            // Lbl_Mobile_No
            // 
            this.Lbl_Mobile_No.AutoSize = true;
            this.Lbl_Mobile_No.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Mobile_No.Location = new System.Drawing.Point(119, 377);
            this.Lbl_Mobile_No.Name = "Lbl_Mobile_No";
            this.Lbl_Mobile_No.Size = new System.Drawing.Size(164, 34);
            this.Lbl_Mobile_No.TabIndex = 0;
            this.Lbl_Mobile_No.Text = "Mobile No";
            // 
            // Lbl_DOB
            // 
            this.Lbl_DOB.AutoSize = true;
            this.Lbl_DOB.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_DOB.Location = new System.Drawing.Point(119, 489);
            this.Lbl_DOB.Name = "Lbl_DOB";
            this.Lbl_DOB.Size = new System.Drawing.Size(87, 34);
            this.Lbl_DOB.TabIndex = 0;
            this.Lbl_DOB.Text = "DOB";
            this.Lbl_DOB.Click += new System.EventHandler(this.Lbl_DOB_Click);
            // 
            // Lbl_Pass
            // 
            this.Lbl_Pass.AutoSize = true;
            this.Lbl_Pass.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Pass.Location = new System.Drawing.Point(119, 592);
            this.Lbl_Pass.Name = "Lbl_Pass";
            this.Lbl_Pass.Size = new System.Drawing.Size(109, 34);
            this.Lbl_Pass.TabIndex = 0;
            this.Lbl_Pass.Text = "Course";
            // 
            // Btn_Save
            // 
            this.Btn_Save.BackColor = System.Drawing.Color.Gainsboro;
            this.Btn_Save.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold);
            this.Btn_Save.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Btn_Save.Location = new System.Drawing.Point(393, 730);
            this.Btn_Save.Name = "Btn_Save";
            this.Btn_Save.Size = new System.Drawing.Size(160, 58);
            this.Btn_Save.TabIndex = 6;
            this.Btn_Save.Text = "Save";
            this.Btn_Save.UseVisualStyleBackColor = false;
            this.Btn_Save.Click += new System.EventHandler(this.Btn_Save_Click);
            // 
            // Tb_Name
            // 
            this.Tb_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Tb_Name.Font = new System.Drawing.Font("Lucida Bright", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tb_Name.Location = new System.Drawing.Point(729, 162);
            this.Tb_Name.MaxLength = 30;
            this.Tb_Name.Multiline = true;
            this.Tb_Name.Name = "Tb_Name";
            this.Tb_Name.Size = new System.Drawing.Size(553, 44);
            this.Tb_Name.TabIndex = 1;
            // 
            // Tb_Roll_No
            // 
            this.Tb_Roll_No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Tb_Roll_No.Font = new System.Drawing.Font("Lucida Bright", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tb_Roll_No.Location = new System.Drawing.Point(729, 274);
            this.Tb_Roll_No.MaxLength = 5;
            this.Tb_Roll_No.Multiline = true;
            this.Tb_Roll_No.Name = "Tb_Roll_No";
            this.Tb_Roll_No.Size = new System.Drawing.Size(553, 42);
            this.Tb_Roll_No.TabIndex = 2;
            this.Tb_Roll_No.TextChanged += new System.EventHandler(this.Tb_Roll_No_TextChanged);
            // 
            // Tb_No
            // 
            this.Tb_No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Tb_No.Font = new System.Drawing.Font("Lucida Bright", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tb_No.Location = new System.Drawing.Point(729, 377);
            this.Tb_No.MaxLength = 10;
            this.Tb_No.Multiline = true;
            this.Tb_No.Name = "Tb_No";
            this.Tb_No.Size = new System.Drawing.Size(553, 41);
            this.Tb_No.TabIndex = 3;
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dtp_DOB.Font = new System.Drawing.Font("Lucida Bright", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_DOB.Location = new System.Drawing.Point(729, 489);
            this.dtp_DOB.MaxDate = new System.DateTime(2026, 6, 1, 0, 0, 0, 0);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.Size = new System.Drawing.Size(553, 39);
            this.dtp_DOB.TabIndex = 4;
            this.dtp_DOB.Value = new System.DateTime(2002, 1, 6, 0, 0, 0, 0);
            this.dtp_DOB.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // Cmb_Course
            // 
            this.Cmb_Course.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cmb_Course.Font = new System.Drawing.Font("Lucida Bright", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_Course.FormattingEnabled = true;
            this.Cmb_Course.Items.AddRange(new object[] {
            "BCA",
            "BCS",
            "Bsc.C.S",
            "MCA",
            "MCA",
            "BTech",
            "MTech"});
            this.Cmb_Course.Location = new System.Drawing.Point(729, 592);
            this.Cmb_Course.Name = "Cmb_Course";
            this.Cmb_Course.Size = new System.Drawing.Size(553, 34);
            this.Cmb_Course.TabIndex = 5;
            this.Cmb_Course.SelectedIndexChanged += new System.EventHandler(this.Cmb_Course_SelectedIndexChanged);
            // 
            // Btn_student_List
            // 
            this.Btn_student_List.BackColor = System.Drawing.Color.Gainsboro;
            this.Btn_student_List.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold);
            this.Btn_student_List.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Btn_student_List.Location = new System.Drawing.Point(1078, 730);
            this.Btn_student_List.Name = "Btn_student_List";
            this.Btn_student_List.Size = new System.Drawing.Size(329, 58);
            this.Btn_student_List.TabIndex = 7;
            this.Btn_student_List.Text = "View Student List ";
            this.Btn_student_List.UseVisualStyleBackColor = false;
            this.Btn_student_List.Click += new System.EventHandler(this.Btn_student_List_Click);
            // 
            // Btn_Refresh
            // 
            this.Btn_Refresh.BackColor = System.Drawing.Color.Gainsboro;
            this.Btn_Refresh.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold);
            this.Btn_Refresh.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Btn_Refresh.Location = new System.Drawing.Point(67, 730);
            this.Btn_Refresh.Name = "Btn_Refresh";
            this.Btn_Refresh.Size = new System.Drawing.Size(216, 58);
            this.Btn_Refresh.TabIndex = 7;
            this.Btn_Refresh.Text = "Refresh";
            this.Btn_Refresh.UseVisualStyleBackColor = false;
            this.Btn_Refresh.Click += new System.EventHandler(this.Btn_Refresh_Click);
            // 
            // btn_logout
            // 
            this.btn_logout.BackColor = System.Drawing.Color.Red;
            this.btn_logout.Font = new System.Drawing.Font("Lucida Bright", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btn_logout.Location = new System.Drawing.Point(1307, 0);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(133, 47);
            this.btn_logout.TabIndex = 9;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.button1_Click);
            // 
            // Btn_User
            // 
            this.Btn_User.BackColor = System.Drawing.Color.LightSlateGray;
            this.Btn_User.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Btn_User.Location = new System.Drawing.Point(-3, 0);
            this.Btn_User.Name = "Btn_User";
            this.Btn_User.Size = new System.Drawing.Size(153, 38);
            this.Btn_User.TabIndex = 28;
            this.Btn_User.Text = "User";
            this.Btn_User.UseVisualStyleBackColor = false;
            // 
            // Btn_Update_Student
            // 
            this.Btn_Update_Student.BackColor = System.Drawing.Color.Gainsboro;
            this.Btn_Update_Student.Font = new System.Drawing.Font("Modern No. 20", 19.8F, System.Drawing.FontStyle.Bold);
            this.Btn_Update_Student.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Btn_Update_Student.Location = new System.Drawing.Point(652, 730);
            this.Btn_Update_Student.Name = "Btn_Update_Student";
            this.Btn_Update_Student.Size = new System.Drawing.Size(320, 58);
            this.Btn_Update_Student.TabIndex = 8;
            this.Btn_Update_Student.Text = "Update Student";
            this.Btn_Update_Student.UseVisualStyleBackColor = false;
            this.Btn_Update_Student.Click += new System.EventHandler(this.Btn_Update_Student_Click);
            // 
            // Frm_Add_New_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(1439, 825);
            this.Controls.Add(this.Btn_Update_Student);
            this.Controls.Add(this.Btn_User);
            this.Controls.Add(this.Btn_Refresh);
            this.Controls.Add(this.Btn_student_List);
            this.Controls.Add(this.btn_logout);
            this.Controls.Add(this.Cmb_Course);
            this.Controls.Add(this.dtp_DOB);
            this.Controls.Add(this.Tb_No);
            this.Controls.Add(this.Tb_Roll_No);
            this.Controls.Add(this.Tb_Name);
            this.Controls.Add(this.Btn_Save);
            this.Controls.Add(this.Lbl_Pass);
            this.Controls.Add(this.Lbl_DOB);
            this.Controls.Add(this.Lbl_Mobile_No);
            this.Controls.Add(this.Lbl_Name);
            this.Controls.Add(this.Lbl_Roll_No);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Frm_Add_New_Student";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Students Details";
            this.Load += new System.EventHandler(this.Frm_Add_New_Student_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lbl_Roll_No;
        private System.Windows.Forms.Label Lbl_Name;
        private System.Windows.Forms.Label Lbl_Mobile_No;
        private System.Windows.Forms.Label Lbl_DOB;
        private System.Windows.Forms.Label Lbl_Pass;
        private System.Windows.Forms.Button Btn_Save;
        private System.Windows.Forms.TextBox Tb_Name;
        private System.Windows.Forms.TextBox Tb_Roll_No;
        private System.Windows.Forms.TextBox Tb_No;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
        private System.Windows.Forms.ComboBox Cmb_Course;
        private System.Windows.Forms.Button Btn_student_List;
        private System.Windows.Forms.Button Btn_Refresh;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Button Btn_User;
        private System.Windows.Forms.Button Btn_Update_Student;
    }
}