﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Student_Addmission_Form
{
    public partial class Frm_Add_New_Student : Form
    {
        public Frm_Add_New_Student()
        {
            InitializeComponent();
        }

        public SqlConnection FCon = new SqlConnection(@"Data Source=LAPTOP-AV981VQ7;Initial Catalog=Student_Addmission_Form_DB;Integrated Security=True");

        void FConStart()
        {
            if (FCon.State != ConnectionState.Open)
            {
                FCon.Open();
            }
        }

        void FConStop()
        {
            if (FCon.State != ConnectionState.Closed)
            {
                FCon.Close();
            }
        }

        void ClearControls()
        {
            Tb_Name.Clear();
            Tb_Roll_No.Clear();
            Tb_No.Clear();
            dtp_DOB.ResetText();
            Cmb_Course.SelectedIndex = -1;
        }
        private void Btn_Refresh_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void Btn_Save_Click(object sender, EventArgs e)
        {
            FConStart();

            if (Tb_Name.Text != "" && Tb_Roll_No.Text != "" && Tb_No.Text != "" && Cmb_Course.Text != "")
            {
                SqlCommand Cmd = new SqlCommand();
                Cmd.Connection = FCon;
                Cmd.CommandText = " Insert Into Student_Info_DB Values(@Nm, @RNo, @MNo, @DOB, @Course)";

                Cmd.Parameters.Add("Nm", SqlDbType.VarChar).Value = Tb_Name.Text;
                Cmd.Parameters.Add("RNo", SqlDbType.Int).Value = Tb_Roll_No.Text;
                Cmd.Parameters.Add("MNo", SqlDbType.Decimal).Value = Tb_No.Text;
                Cmd.Parameters.Add("DOB", SqlDbType.Date).Value = dtp_DOB.Text;
                Cmd.Parameters.Add("Course", SqlDbType.NVarChar).Value = Cmb_Course.Text;

                int Cnt = Cmd.ExecuteNonQuery();
                if (Cnt > 0)
                {
                    MessageBox.Show("Student Info Saved Successfully.", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


                ClearControls();
            }

            else
            {
                MessageBox.Show("1st Fill All Details!!!", "Incomplete Details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            FConStop();
        }

        private void Btn_student_List_Click(object sender, EventArgs e)
        {
            Frm_Student_List obj = new Frm_Student_List();
            this.Hide();
            obj.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FRM_Login Obj = new FRM_Login();
            Obj.Show();
            this.Hide();
        }

        private void Frm_Add_New_Student_Load(object sender, EventArgs e)
        {

        }

        private void Lbl_DOB_Click(object sender, EventArgs e)
        {

        }

        private void Lbl_Roll_No_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Tb_Roll_No_TextChanged(object sender, EventArgs e)
        {

        }

        private void Cmb_Course_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Update_Student_Click(object sender, EventArgs e)
        {
            FRM_Update_Student_Details obj = new FRM_Update_Student_Details();
            obj.Show();
            this.Hide();
                
        }
    }
}
