﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Addmission_Form
{
    public partial class Frm_Student_List : Form
    {
        public Frm_Student_List()
        {
            InitializeComponent();
        }

        private void Btn_Add_New_Student_Click(object sender, EventArgs e)
        {
            Frm_Add_New_Student obj = new Frm_Add_New_Student();
            this.Hide();
            obj.Show();
        }
        private void btn_Log_Out_Click(object sender, EventArgs e)
        {
            FRM_Login obj = new FRM_Login();
            this.Hide();
            obj.Show();
          
        }

        private void Lbl_Header_Click(object sender, EventArgs e)
        {

        }

        private void Frm_Student_List_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'student_Addmission_Form_DBDataSet.Student_Info_DB' table. You can move, or remove it, as needed.
            this.student_Info_DBTableAdapter.Fill(this.student_Addmission_Form_DBDataSet.Student_Info_DB);

        }
    }
}
