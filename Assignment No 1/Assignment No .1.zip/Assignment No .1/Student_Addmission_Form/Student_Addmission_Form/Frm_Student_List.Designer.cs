﻿
namespace Student_Addmission_Form
{
    partial class Frm_Student_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Lbl_Header = new System.Windows.Forms.Label();
            this.btn_Log_Out = new System.Windows.Forms.Button();
            this.Btn_Add_New_Student = new System.Windows.Forms.Button();
            this.Dgv_Student_List = new System.Windows.Forms.DataGridView();
            this.studentInfoDBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_Addmission_Form_DBDataSet = new Student_Addmission_Form.Student_Addmission_Form_DBDataSet();
            this.student_Info_DBTableAdapter = new Student_Addmission_Form.Student_Addmission_Form_DBDataSetTableAdapters.Student_Info_DBTableAdapter();
            this.Btn_User = new System.Windows.Forms.Button();
            this.Btn_Search_student = new System.Windows.Forms.Button();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rollNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobileNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Student_List)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentInfoDBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_Addmission_Form_DBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_Header
            // 
            this.Lbl_Header.AutoSize = true;
            this.Lbl_Header.BackColor = System.Drawing.Color.PapayaWhip;
            this.Lbl_Header.Font = new System.Drawing.Font("Rockwell", 48F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Lbl_Header.ForeColor = System.Drawing.Color.DarkGreen;
            this.Lbl_Header.Location = new System.Drawing.Point(448, 9);
            this.Lbl_Header.Name = "Lbl_Header";
            this.Lbl_Header.Size = new System.Drawing.Size(525, 99);
            this.Lbl_Header.TabIndex = 0;
            this.Lbl_Header.Text = "Students List";
            this.Lbl_Header.Click += new System.EventHandler(this.Lbl_Header_Click);
            // 
            // btn_Log_Out
            // 
            this.btn_Log_Out.BackColor = System.Drawing.Color.Red;
            this.btn_Log_Out.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Log_Out.Location = new System.Drawing.Point(1316, -1);
            this.btn_Log_Out.Name = "btn_Log_Out";
            this.btn_Log_Out.Size = new System.Drawing.Size(124, 55);
            this.btn_Log_Out.TabIndex = 3;
            this.btn_Log_Out.Text = "Log Out";
            this.btn_Log_Out.UseVisualStyleBackColor = false;
            this.btn_Log_Out.Click += new System.EventHandler(this.btn_Log_Out_Click);
            // 
            // Btn_Add_New_Student
            // 
            this.Btn_Add_New_Student.BackColor = System.Drawing.Color.Gainsboro;
            this.Btn_Add_New_Student.Font = new System.Drawing.Font("Modern No. 20", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Add_New_Student.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Btn_Add_New_Student.Location = new System.Drawing.Point(906, 733);
            this.Btn_Add_New_Student.Name = "Btn_Add_New_Student";
            this.Btn_Add_New_Student.Size = new System.Drawing.Size(427, 70);
            this.Btn_Add_New_Student.TabIndex = 2;
            this.Btn_Add_New_Student.Text = "Add New Student";
            this.Btn_Add_New_Student.UseVisualStyleBackColor = false;
            this.Btn_Add_New_Student.Click += new System.EventHandler(this.Btn_Add_New_Student_Click);
            // 
            // Dgv_Student_List
            // 
            this.Dgv_Student_List.AllowUserToAddRows = false;
            this.Dgv_Student_List.AllowUserToDeleteRows = false;
            this.Dgv_Student_List.AutoGenerateColumns = false;
            this.Dgv_Student_List.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Student_List.BackgroundColor = System.Drawing.Color.LightBlue;
            this.Dgv_Student_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Student_List.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentNameDataGridViewTextBoxColumn,
            this.rollNoDataGridViewTextBoxColumn,
            this.mobileNoDataGridViewTextBoxColumn,
            this.dOBDataGridViewTextBoxColumn,
            this.courseDataGridViewTextBoxColumn});
            this.Dgv_Student_List.DataSource = this.studentInfoDBBindingSource;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Menu;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.NullValue = null;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Pink;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Dgv_Student_List.DefaultCellStyle = dataGridViewCellStyle1;
            this.Dgv_Student_List.Location = new System.Drawing.Point(12, 119);
            this.Dgv_Student_List.Name = "Dgv_Student_List";
            this.Dgv_Student_List.ReadOnly = true;
            this.Dgv_Student_List.RowHeadersWidth = 51;
            this.Dgv_Student_List.RowTemplate.Height = 24;
            this.Dgv_Student_List.Size = new System.Drawing.Size(1415, 593);
            this.Dgv_Student_List.TabIndex = 9;
            // 
            // studentInfoDBBindingSource
            // 
            this.studentInfoDBBindingSource.DataMember = "Student_Info_DB";
            this.studentInfoDBBindingSource.DataSource = this.student_Addmission_Form_DBDataSet;
            // 
            // student_Addmission_Form_DBDataSet
            // 
            this.student_Addmission_Form_DBDataSet.DataSetName = "Student_Addmission_Form_DBDataSet";
            this.student_Addmission_Form_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // student_Info_DBTableAdapter
            // 
            this.student_Info_DBTableAdapter.ClearBeforeFill = true;
            // 
            // Btn_User
            // 
            this.Btn_User.BackColor = System.Drawing.Color.LightSlateGray;
            this.Btn_User.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Btn_User.Location = new System.Drawing.Point(1, -1);
            this.Btn_User.Name = "Btn_User";
            this.Btn_User.Size = new System.Drawing.Size(153, 38);
            this.Btn_User.TabIndex = 28;
            this.Btn_User.Text = "User";
            this.Btn_User.UseVisualStyleBackColor = false;
            // 
            // Btn_Search_student
            // 
            this.Btn_Search_student.BackColor = System.Drawing.Color.Gainsboro;
            this.Btn_Search_student.Font = new System.Drawing.Font("Modern No. 20", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Search_student.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Btn_Search_student.Location = new System.Drawing.Point(88, 733);
            this.Btn_Search_student.Name = "Btn_Search_student";
            this.Btn_Search_student.Size = new System.Drawing.Size(376, 70);
            this.Btn_Search_student.TabIndex = 1;
            this.Btn_Search_student.Text = "Search Student";
            this.Btn_Search_student.UseVisualStyleBackColor = false;
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.FillWeight = 40F;
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.MinimumWidth = 500;
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            this.studentNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rollNoDataGridViewTextBoxColumn
            // 
            this.rollNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.rollNoDataGridViewTextBoxColumn.DataPropertyName = "Roll_No";
            this.rollNoDataGridViewTextBoxColumn.FillWeight = 12F;
            this.rollNoDataGridViewTextBoxColumn.HeaderText = "Roll_No";
            this.rollNoDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.rollNoDataGridViewTextBoxColumn.Name = "rollNoDataGridViewTextBoxColumn";
            this.rollNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // mobileNoDataGridViewTextBoxColumn
            // 
            this.mobileNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.mobileNoDataGridViewTextBoxColumn.DataPropertyName = "Mobile_No";
            this.mobileNoDataGridViewTextBoxColumn.FillWeight = 18F;
            this.mobileNoDataGridViewTextBoxColumn.HeaderText = "Mobile_No";
            this.mobileNoDataGridViewTextBoxColumn.MinimumWidth = 100;
            this.mobileNoDataGridViewTextBoxColumn.Name = "mobileNoDataGridViewTextBoxColumn";
            this.mobileNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dOBDataGridViewTextBoxColumn
            // 
            this.dOBDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dOBDataGridViewTextBoxColumn.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn.FillWeight = 15F;
            this.dOBDataGridViewTextBoxColumn.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dOBDataGridViewTextBoxColumn.Name = "dOBDataGridViewTextBoxColumn";
            this.dOBDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // courseDataGridViewTextBoxColumn
            // 
            this.courseDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.courseDataGridViewTextBoxColumn.DataPropertyName = "Course";
            this.courseDataGridViewTextBoxColumn.FillWeight = 15F;
            this.courseDataGridViewTextBoxColumn.HeaderText = "Course";
            this.courseDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.courseDataGridViewTextBoxColumn.Name = "courseDataGridViewTextBoxColumn";
            this.courseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Frm_Student_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(1439, 825);
            this.Controls.Add(this.Btn_Search_student);
            this.Controls.Add(this.Btn_User);
            this.Controls.Add(this.Dgv_Student_List);
            this.Controls.Add(this.Btn_Add_New_Student);
            this.Controls.Add(this.btn_Log_Out);
            this.Controls.Add(this.Lbl_Header);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Frm_Student_List";
            this.Text = "Students List";
            this.Load += new System.EventHandler(this.Frm_Student_List_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Student_List)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentInfoDBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_Addmission_Form_DBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_Header;
        private System.Windows.Forms.Button btn_Log_Out;
        private System.Windows.Forms.Button Btn_Add_New_Student;
        private System.Windows.Forms.DataGridView Dgv_Student_List;
        private Student_Addmission_Form_DBDataSet student_Addmission_Form_DBDataSet;
        private System.Windows.Forms.BindingSource studentInfoDBBindingSource;
        private Student_Addmission_Form_DBDataSetTableAdapters.Student_Info_DBTableAdapter student_Info_DBTableAdapter;
        private System.Windows.Forms.Button Btn_User;
        private System.Windows.Forms.Button Btn_Search_student;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rollNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobileNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseDataGridViewTextBoxColumn;
    }
}