﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Addmission_Form
{
    public partial class FRM_Login : Form
    {
        public FRM_Login()
        {
            InitializeComponent();
        }

        private void frm_Login_Load(object sender, EventArgs e)
        {
            tb_Username.Focus();
        }
        private void tb_Username_TextChanged(object sender, EventArgs e)
        {
            tb_password.Enabled = true;
        }

        private void tb_password_TextChanged(object sender, EventArgs e)
        {
            btn_Submit.Enabled = true;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if ( (tb_Username.Text.Trim().ToLower() == "harshada" && tb_password.Text.Trim() == "2629") || (tb_Username.Text.Trim().ToLower() == "sam" && tb_password.Text.Trim() == "2629"))
            {
                MessageBox.Show("WELCOME", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Frm_Add_New_Student obj = new Frm_Add_New_Student();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect Username Or Password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            tb_Username.Clear();
            tb_password.Clear();
            tb_password.Enabled = false;
            btn_Submit.Enabled = false;
        }

    
    }
 
}
